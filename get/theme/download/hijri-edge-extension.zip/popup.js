(function () {
  const {
    HIJRI_MONTHS_EN,
    HIJRI_MONTHS_BN,
    toShortGregLabel,
    addDaysUTC,
    isSameUTCDate,
    isoWeekdayIndex,
    hijriMonthLengthForList
  } = HijriCore;

  const { loadMergedAnchors, computeToday, getSettings, setSettings } = HijriShared;

  const WEEKDAYS_EN = ["M", "T", "W", "T", "F", "S", "S"];

  let anchors = [];
  let viewMonth = null;
  let viewYear = null;

  /* ---------------- Today row ---------------- */

  const loadingState = document.getElementById("loadingState");
  const errorState = document.getElementById("errorState");
  const todayContent = document.getElementById("todayContent");
  const hijriNumeric = document.getElementById("hijriNumeric");
  const hijriEnLine = document.getElementById("hijriEnLine");
  const hijriBnLine = document.getElementById("hijriBnLine");
  const gregFooter = document.getElementById("gregFooter");
  const monthCard = document.getElementById("monthCard");

  function showError() {
    loadingState.hidden = true;
    todayContent.hidden = true;
    errorState.hidden = false;
    monthCard.hidden = true;
  }

  function showToday(data) {
    hijriNumeric.textContent = data.hijri.day;
    hijriEnLine.textContent = `${data.hijri.monthNameEn} ${data.hijri.year}`;
    hijriBnLine.textContent = `${data.hijri.monthNameBn} ${data.hijri.year}`;

    const greg = new Date(data.gregorianDate + "T00:00:00Z");
    gregFooter.textContent = greg.toLocaleDateString("en-US", {
      weekday: "long",
      month: "short",
      day: "numeric",
      year: "numeric",
      timeZone: "UTC"
    });

    loadingState.hidden = true;
    errorState.hidden = true;
    todayContent.hidden = false;
    monthCard.hidden = false;
  }

  /* ---------------- Month calendar grid ---------------- */

  const monthTitle = document.getElementById("monthTitle");
  const weekdayRow = document.getElementById("weekdayRow");
  const daysGrid = document.getElementById("daysGrid");
  const prevMonthBtn = document.getElementById("prevMonthBtn");
  const nextMonthBtn = document.getElementById("nextMonthBtn");

  function renderWeekdayRow() {
    weekdayRow.innerHTML = "";
    WEEKDAYS_EN.forEach((d) => {
      const span = document.createElement("span");
      span.textContent = d;
      weekdayRow.appendChild(span);
    });
  }

  function renderMonth() {
    const { computeGregStartForList } = HijriCore;
    const startDate = computeGregStartForList(anchors, viewMonth, viewYear);
    const monthLen = hijriMonthLengthForList(anchors, viewMonth, viewYear);

    monthTitle.textContent = `${HIJRI_MONTHS_EN[viewMonth - 1]} ${viewYear}`;

    daysGrid.innerHTML = "";
    const leadingEmpty = isoWeekdayIndex(startDate); // 0=Mon

    const now = new Date();
    const todayUTC = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));

    for (let i = 0; i < leadingEmpty; i++) {
      const empty = document.createElement("div");
      empty.className = "day-cell other-month";
      daysGrid.appendChild(empty);
    }

    for (let dayNum = 1; dayNum <= monthLen; dayNum++) {
      const gregDate = addDaysUTC(startDate, dayNum - 1);
      const weekdayIdx = isoWeekdayIndex(gregDate);
      const isFriday = weekdayIdx === 4;
      const isToday = isSameUTCDate(gregDate, todayUTC);

      const cell = document.createElement("div");
      cell.className = "day-cell" + (isFriday ? " friday" : "") + (isToday ? " today" : "");

      const num = document.createElement("span");
      num.textContent = dayNum;

      const greg = document.createElement("span");
      greg.className = "greg-day";
      greg.textContent = toShortGregLabel(gregDate);

      cell.appendChild(num);
      cell.appendChild(greg);
      daysGrid.appendChild(cell);
    }
  }

  function shiftMonth(delta) {
    viewMonth += delta;
    if (viewMonth > 12) { viewMonth = 1; viewYear += 1; }
    if (viewMonth < 1) { viewMonth = 12; viewYear -= 1; }
    renderMonth();
  }

  prevMonthBtn.addEventListener("click", () => shiftMonth(-1));
  nextMonthBtn.addEventListener("click", () => shiftMonth(1));

  /* ---------------- Settings panel ---------------- */

  const settingsToggle = document.getElementById("settingsToggle");
  const settingsPanel = document.getElementById("settingsPanel");
  const toggleOpenBtn = document.getElementById("toggleOpenBtn");
  const toggleNewTabTheme = document.getElementById("toggleNewTabTheme");

  settingsToggle.addEventListener("click", () => {
    const isOpen = !settingsPanel.hidden;
    settingsPanel.hidden = isOpen;
    settingsToggle.setAttribute("aria-expanded", String(!isOpen));
  });

  toggleOpenBtn.addEventListener("change", () => {
    setSettings({ showOpenButtonOnNewTab: toggleOpenBtn.checked });
  });

  toggleNewTabTheme.addEventListener("change", () => {
    setSettings({ newTabThemeEnabled: toggleNewTabTheme.checked });
  });

  async function initSettings() {
    const settings = await getSettings();
    toggleOpenBtn.checked = settings.showOpenButtonOnNewTab === true;
    toggleNewTabTheme.checked = settings.newTabThemeEnabled !== false;
  }

  /* ---------------- Init ---------------- */

  async function init() {
    renderWeekdayRow();
    try {
      anchors = await loadMergedAnchors();
      const today = computeToday(anchors);
      viewMonth = today.hijri.month;
      viewYear = today.hijri.year;
      showToday(today);
      renderMonth();
    } catch (e) {
      showError();
    }
    initSettings();
  }

  init();
})();
