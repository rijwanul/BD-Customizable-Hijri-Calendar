/* =========================================================
   shared.js
   Logic shared between newtab.js and popup.js:
   - loading anchors (live fetch, cached, or bundled fallback)
   - reading/writing the "show Open Hijri Calendar button" setting
========================================================= */

(function (global) {

  const LIVE_ANCHORS_URL = "https://hijri.iiuc.net/anchors.json";
  const ANCHORS_CACHE_KEY = "hijriCachedAnchorsRaw_v1"; // raw dd/mm/yyyy anchors array, as fetched
  const SETTINGS_KEY = "hijriExtensionSettings_v1";

  const DEFAULT_SETTINGS = {
    showOpenButtonOnNewTab: false,
    newTabThemeEnabled: true
  };

  function hasStorage() {
    return typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  }

  function getCachedRawAnchors() {
    return new Promise((resolve) => {
      if (!hasStorage()) return resolve(null);
      chrome.storage.local.get([ANCHORS_CACHE_KEY], (result) => {
        if (chrome.runtime.lastError || !result || !Array.isArray(result[ANCHORS_CACHE_KEY])) {
          return resolve(null);
        }
        resolve(result[ANCHORS_CACHE_KEY]);
      });
    });
  }

  function setCachedRawAnchors(rawAnchors) {
    if (!hasStorage()) return;
    chrome.storage.local.set({ [ANCHORS_CACHE_KEY]: rawAnchors });
  }

  // Tries the live anchors.json from the website first. If it succeeds and
  // differs from what's cached, saves it to chrome.storage.local so future
  // popups/new tabs stay current even offline. If the live fetch fails,
  // uses the cached copy if one exists; only falls back to the bundled
  // read-only anchors.json (via hijri-core.js's own fetch) on a true first
  // run with no cache and no network.
  async function loadAnchors() {
    const { normalizeAnchorList, fetchShippedAnchors } = global.HijriCore;

    let liveRaw = null;
    try {
      const res = await fetch(LIVE_ANCHORS_URL, { cache: "no-store" });
      if (!res.ok) throw new Error(`Live anchors.json responded with ${res.status}`);
      const data = await res.json();
      if (data && Array.isArray(data.anchors) && data.anchors.length > 0) {
        liveRaw = data.anchors;
      }
    } catch (e) {
      liveRaw = null; // network error, offline, site down, etc.
    }

    if (liveRaw) {
      const normalized = normalizeAnchorList(liveRaw);
      if (normalized.length > 0) {
        const cached = await getCachedRawAnchors();
        if (JSON.stringify(cached) !== JSON.stringify(liveRaw)) {
          setCachedRawAnchors(liveRaw);
        }
        return normalized;
      }
    }

    const cachedRaw = await getCachedRawAnchors();
    if (cachedRaw) {
      const normalized = normalizeAnchorList(cachedRaw);
      if (normalized.length > 0) return normalized;
    }

    return fetchShippedAnchors();
  }

  // Merges shipped/cached anchors with the user's own Set Start Date
  // anchors (kept in localStorage by hijri-core.js).
  async function loadMergedAnchors() {
    const { loadUserAnchors, mergeAnchors } = global.HijriCore;
    const shippedAnchors = await loadAnchors();
    const userAnchors = loadUserAnchors();
    return mergeAnchors(shippedAnchors, userAnchors);
  }

  // Computes today's Hijri date from a merged anchor list, in the same
  // shape newtab.js/popup.js render from.
  function computeToday(anchors) {
    const {
      HIJRI_MONTHS_EN,
      HIJRI_MONTHS_AR,
      HIJRI_MONTHS_BN,
      toISODate,
      toHijriNumericDate,
      gregorianToHijriList
    } = global.HijriCore;

    const now = new Date();
    const todayUTC = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
    const { hijriDay, hijriMonth, hijriYear } = gregorianToHijriList(anchors, todayUTC);

    return {
      gregorianDate: toISODate(todayUTC),
      hijri: {
        day: hijriDay,
        month: hijriMonth,
        monthNameEn: HIJRI_MONTHS_EN[hijriMonth - 1],
        monthNameAr: HIJRI_MONTHS_AR[hijriMonth - 1],
        monthNameBn: HIJRI_MONTHS_BN[hijriMonth - 1],
        year: hijriYear,
        numeric: toHijriNumericDate(hijriDay, hijriMonth, hijriYear)
      }
    };
  }

  /* ---------------- Settings ---------------- */

  function getSettings() {
    return new Promise((resolve) => {
      if (!hasStorage()) return resolve({ ...DEFAULT_SETTINGS });
      chrome.storage.local.get([SETTINGS_KEY], (result) => {
        const stored = (result && result[SETTINGS_KEY]) || {};
        resolve({ ...DEFAULT_SETTINGS, ...stored });
      });
    });
  }

  function setSettings(partial) {
    return new Promise((resolve) => {
      if (!hasStorage()) return resolve();
      getSettings().then((current) => {
        const merged = { ...current, ...partial };
        chrome.storage.local.set({ [SETTINGS_KEY]: merged }, () => resolve(merged));
      });
    });
  }

  // Notifies other open extension pages (e.g. an already-open new tab) that
  // settings changed, so they can update live without needing a reload.
  function onSettingsChanged(callback) {
    if (!hasStorage()) return;
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === "local" && changes[SETTINGS_KEY]) {
        callback(changes[SETTINGS_KEY].newValue || { ...DEFAULT_SETTINGS });
      }
    });
  }

  global.HijriShared = {
    DEFAULT_SETTINGS,
    loadAnchors,
    loadMergedAnchors,
    computeToday,
    getSettings,
    setSettings,
    onSettingsChanged
  };

})(typeof self !== "undefined" ? self : this);
