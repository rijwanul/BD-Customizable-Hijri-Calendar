(function () {
  const { loadMergedAnchors, computeToday, getSettings, onSettingsChanged } = HijriShared;

  const card = document.getElementById("card");
  const loadingState = document.getElementById("loadingState");
  const errorState = document.getElementById("errorState");
  const content = document.getElementById("content");

  const gregLine = document.getElementById("gregLine");
  const hijriNumeric = document.getElementById("hijriNumeric");
  const hijriEnLine = document.getElementById("hijriEnLine");
  const hijriArLine = document.getElementById("hijriArLine");
  const hijriBnLine = document.getElementById("hijriBnLine");

  let hijriLoadStarted = false;

  function resetPanels() {
    loadingState.hidden = false;
    content.hidden = true;
    errorState.hidden = true;
  }

  function showError() {
    loadingState.hidden = true;
    content.hidden = true;
    errorState.hidden = false;
  }

  function showContent(data) {
    const greg = new Date(data.gregorianDate + "T00:00:00Z");
    const gregLabel = greg.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      timeZone: "UTC"
    });

    gregLine.textContent = gregLabel;
    hijriNumeric.textContent = data.hijri.numeric;
    hijriEnLine.textContent = `${data.hijri.day} ${data.hijri.monthNameEn} ${data.hijri.year}`;
    hijriArLine.textContent = `${data.hijri.day} ${data.hijri.monthNameAr} ${data.hijri.year}`;
    hijriBnLine.textContent = `${data.hijri.day} ${data.hijri.monthNameBn} ${data.hijri.year}`;

    loadingState.hidden = true;
    errorState.hidden = true;
    content.hidden = false;
  }

  async function loadTodayHijri() {
    if (hijriLoadStarted) return; // avoid re-fetching if toggled on repeatedly
    hijriLoadStarted = true;
    resetPanels();
    try {
      const anchors = await loadMergedAnchors();
      showContent(computeToday(anchors));
    } catch (e) {
      showError();
    }
  }

  function applyButtonVisibility(settings) {
    const show = settings.showOpenButtonOnNewTab === true;
    document.querySelectorAll(".open-btn").forEach((el) => {
      el.style.display = show ? "" : "none";
    });
  }

  // Shows/hides just the date card based on the theme setting. The
  // shortcuts grid always stays, so a new tab is never left empty.
  function applyThemeVisibility(settings) {
    const themeOn = settings.newTabThemeEnabled !== false;
    card.hidden = !themeOn;
    if (themeOn) {
      loadTodayHijri();
    }
  }

  /* ---------------- Most-visited shortcuts ---------------- */

  function faviconUrl(pageUrl) {
    try {
      const u = new URL(pageUrl);
      return `https://www.google.com/s2/favicons?sz=64&domain=${u.hostname}`;
    } catch (e) {
      return "";
    }
  }

  function siteLabel(site) {
    if (site.title && site.title.trim()) return site.title.trim();
    try {
      return new URL(site.url).hostname.replace(/^www\./, "");
    } catch (e) {
      return site.url;
    }
  }

  function renderShortcuts(sites) {
    const wrap = document.getElementById("shortcuts");
    wrap.innerHTML = "";

    sites.slice(0, 8).forEach((site) => {
      const a = document.createElement("a");
      a.className = "tile";
      a.href = site.url;
      a.title = siteLabel(site);

      const icon = document.createElement("div");
      icon.className = "tile-icon";
      const img = document.createElement("img");
      img.src = faviconUrl(site.url);
      img.alt = "";
      icon.appendChild(img);

      const label = document.createElement("span");
      label.className = "tile-label";
      label.textContent = siteLabel(site);

      a.appendChild(icon);
      a.appendChild(label);
      wrap.appendChild(a);
    });
  }

  function loadShortcuts() {
    if (!(typeof chrome !== "undefined" && chrome.topSites && chrome.topSites.get)) return;
    chrome.topSites.get((sites) => {
      if (chrome.runtime.lastError || !sites) return;
      renderShortcuts(sites);
    });
  }

  async function init() {
    const settings = await getSettings();
    applyThemeVisibility(settings);
    applyButtonVisibility(settings);
    loadShortcuts();

    // Live updates: no reload needed when settings change from the popup.
    onSettingsChanged((settings) => {
      applyThemeVisibility(settings);
      applyButtonVisibility(settings);
    });
  }

  init();
})();
